package z_homework.extends_test.a02;

public class Shape {
	
	public Shape(){}
	
	// 쉐입 클래스는 파라미터 받는 생성자가 없다는 의미 기본생성자는 ㅇㅇ
	
	public double area() {
		return 0.0;	
		
	}
	public double perimeter() { //퍼리미터 둘레
		return 0.0;
	}
	
}
