package z_homework.extends_test.a03;

public class BankAccount {

	private int balance;
	
	public BankAccount(int balance) {
		this.balance = balance;
	}

	public int getBalance() {
		return balance;
	}

	public void deposit(int amount) {
		
	}
	
	public boolean withdraw(int amount) {
		return false;
		
	}
	
	public boolean transfer(int amount , BankAccount otherAccount) {
		if(this.balance >= amount) {
			this.balance -= amount;
			otherAccount.balance += amount;
			return true; // 조건문 맞으면 참
		}
		return false;
	}
	
	
}
