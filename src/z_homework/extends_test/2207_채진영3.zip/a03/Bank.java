package z_homework.extends_test.a03;

public class Bank {
	private Customer[] customers;
	private int numberOfCustomers;
	
	
	public Bank() {
		customers = new Customer[10]; // 10개 지정된 배열이 생성됨 / 아직 null값임..
	}
	
	public void addCustomer(Customer c) { // 메인에서 고객 클래스로 만든 인스턴스를 가져옴 
		customers[numberOfCustomers] = c; // 고객만 받을수 있는 배열
		numberOfCustomers++; // 배열에 인덱스 번호를 알려주는 값
	}
	public int getNumberOfCustomers() {
		return numberOfCustomers;
	}
	
	public Customer[] getCustomers() {
		return customers;
	}
	
	public Customer getCustomer(int index) {
		return customers[index];
	}
//	public void setNumberOfCustomers(int numberOfCustomers) {
//		this.numberOfCustomers = numberOfCustomers;
//	}
	
	
}
