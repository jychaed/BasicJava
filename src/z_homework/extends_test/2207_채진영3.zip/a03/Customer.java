package z_homework.extends_test.a03;

public class Customer {

	private String firstName;
	private String lastName;
	private BankAccount account;
	
	public Customer(String firstName, String lastName) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		
	}

	public BankAccount getAccount() {
		return account;
	}

	public void setAccount(BankAccount account) {
		this.account = account;
	}

	public String getFirstName() {
		return firstName;
	}

	public String getLastName() {
		return lastName;
	}

	@Override // 내가 이런식으로 변경해서 쓰겠다 재정의를 한다.
	public String toString() {
		return "이름: " + this.firstName + this.lastName + ", 잔고: " + this.account.getBalance() +"원" ;
	}
	
	
	
}
