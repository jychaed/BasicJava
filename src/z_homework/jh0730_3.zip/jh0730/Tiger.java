package z_homework.jh0730;

public class Tiger extends Animal {

	public Tiger() {
		// TODO Auto-generated constructor stub
	}
	

	@Override
	public void walk() {
		// TODO Auto-generated method stub
		System.out.println("호랑이가 걷는다");
	}

	@Override
	public void sound() {
		// TODO Auto-generated method stub
		System.out.println("호랑이가 운다");
	}
	
	public void hunt() {
		System.out.println("사냥한다");
	}
	
}
