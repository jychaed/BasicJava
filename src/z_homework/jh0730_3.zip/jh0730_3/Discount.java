package z_homework.jh0730_3;

public interface Discount {
	public abstract void discountP(Paikcoffee p, String name); // 백다방 10% 할인
	public abstract void discountS(Starbucks sb, String name); // 스타벅스는 20% 할인 

}
