package z_homework.jh0730_3;

public abstract class CoffeeShop {
	protected String name; // 이름
	protected int sales; // 매출
	protected int americano;
	protected int latte;
	protected int numOfCustomer; // 고객 받은 수
	
	
	
	public abstract void showInfo();
	
}
