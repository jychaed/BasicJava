package z_homework.jh0730_3;


public class Customer {
	String name; //고객이름
	int age; //고객나이
	int money; // 고객이 구매한 돈
	
	public Customer(String name, int money) {
		this.name = name;
		this.money = money;
	}



	
	
}
