package z_homework.jh0730_2;

public abstract class Human extends Creature implements Talkable{
	//String name , int age, String color 
	
	Human(){
		this.name = "인간";
		this.color = "살색";
		this.age = 0;
		
	}

    
	
	
}
