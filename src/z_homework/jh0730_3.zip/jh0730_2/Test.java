package z_homework.jh0730_2;

public class Test {

	public static void main(String[] args) {
		Chae c = new Chae();
		c.showInfo();
		c.talk();
		c.talk();
		c.talkable();
	}

}
